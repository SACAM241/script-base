# fxserver-esx_barbershop
FXServer ESX Barber Shop

[REQUIREMENTS]

- esx_skin => https://github.com/FXServer-ESX/fxserver-esx_skin

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/FXServer-ESX/fxserver-esx_barbershop esx_barbershop
```
3) Add this in your server.cfg :

```
start esx_barbershop
```
