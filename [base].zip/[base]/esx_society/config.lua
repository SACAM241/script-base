Config                    = {}
Config.Locale             = 'fr'
Config.EnableESXIdentity  = true
Config.MaxSalary          = 700
