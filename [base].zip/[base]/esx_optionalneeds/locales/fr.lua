Locales['fr'] = {
	
	['used_beer'] = 'Vous avez utilisé 1x ~y~Bière~s~',
	['used_vine'] = 'Tu as bu un ~y~Vin~s~',
	['used_vodka'] = 'Tu as bu une ~y~vodka~s~',
	['used_whisky'] = 'Tu as bu un ~y~whisky~s~',
	['used_martini'] = 'Tu as bu un ~y~martini~s~',
	['used_tequila'] = 'Tu as bu une ~y~tequila~s~',
	['used_jager'] = 'Tu as bu un ~y~jager~s~',
	['used_rhum'] = 'Tu as bu un verre de ~y~rhum~s~',
	['used_rhumcoca'] = 'Tu as bu un verre de ~y~Rhum Coca~s~',
	['used_jagerbomb'] = 'Tu as bu un verre de ~y~JagerBomb~s~',
	['used_golem'] = 'Tu as bu un verre de ~y~Golem~s~',
	['used_whiskycoca'] = 'Tu as bu un verre de ~y~Whisky Coca~s~',
	['used_vodkafruit'] = 'Tu as bu un verre ~y~Vodka Fruit~s~',
	['used_teqpaf'] = 'Tu as bu un ~y~TeqPaf~s~',
	['used_mojito'] = 'Tu as bu un ~y~Mojito~s~',
	['used_metreshooter'] = 'Tu as bu un ~y~Metre Shooter~s~',
	['used_jagercerbere'] = 'Tu as bu un ~y~jager cerbere~s~',
	['used_vodkaenergy'] = 'Tu as bu un ~y~vodka redbull~s~'

}