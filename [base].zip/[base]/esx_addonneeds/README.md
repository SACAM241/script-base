# fxserver-esx_addonneeds
FXServer ESX Addon Needs

[REQUIREMENTS]

- esx_status => https://github.com/FXServer-ESX/fxserver-esx_status

- esx_gym    => https://github.com/P4NDAzzGaming/esx_gym

[INFO]

basic script that improves endurance etc. small supplement for esx_gym 

[INSTALLATION]

[EN]

1) CD in your resources/[esx] folder
2) Clone the repository
3) place the trigger " TriggerEvent('esx_status:add','force', 80000) " in the esx_gym client
4) Add this in your server.cfg :

[FR]

1) télecharger la ressource 
2) placer le dossier dans votre répertoire
3) placer le trigger  " TriggerEvent('esx_status:add','force', 80000) " dans le client de esx_gym 
4) ajouter a votre server.cfg

```
start esx_addonneeds
```
