description 'ESX Addonneeds'

version '0.0.1'

client_scripts {

	'client.lua'
}
