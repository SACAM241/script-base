Locales['fi'] = {
  ['used_bread'] = 'sinä söit ~y~1x~s~ ~b~leipä~s~',
  ['used_water'] = 'sinä joit ~y~1x~s~ ~b~vesi~s~',
}