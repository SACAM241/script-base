Locales['pl'] = {
  ['skin_menu'] = 'menu wyglądu',
  ['use_rotate_view'] = 'użyj ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ i ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ aby obrócić ekran.',
  ['skin'] = 'zmien wygląd',
  ['saveskin'] = 'zapisz wygląd do pliku',
  ['confirm_escape'] = 'czy chcesz anulować zmianę wyglądu? Wszystkie zmiany zostaną utracone.',
  ['no'] = 'nie',
  ['yes'] = 'tak',
}
